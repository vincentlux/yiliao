<?php
/*
 +----------------------------------------------------------------------+
 | weixin pay notify                                                    |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:04:53                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */

require( '../../../wp-load.php' );
ini_set('date.timezone','Asia/Shanghai');

$config = \Weixin\Factory::getConfig(DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'configs');

$options = get_option($config['options']['register']);
$options = unserialize($options);
$common_options = get_option($config['options']['common']);
$common_options = unserialize($common_options);
$url = $config['common']['request_uri'] . '/wepay.php';

$xml = file_get_contents("php://input");

libxml_disable_entity_loader(true);
$rs = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);	
$mchkey = \Weixin\MyFunctions::myDecrypt($options['mchkey'], $config['common']['cookie_encrypt_key']);
$rs = \Weixin\WeixinResult::Init($xml, $mchkey);

if('SUCCESS' == $rs['result_code'] && 'SUCCESS' == $rs['return_code']) {
    $out_trade_no = $rs['out_trade_no'];
    $respone = '
            <xml>
              <return_code><![CDATA[SUCCESS]]></return_code>
              <return_msg><![CDATA[OK]]></return_msg>
            </xml>
    ';

    global $wpdb;

    $mysqli = new mysqli($wpdb->dbhost, $wpdb->dbuser, $wpdb->dbpassword, $wpdb->dbname);

    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }
    $mysqli->autocommit(FALSE);

    $sql = 'select post_id, total_fee, state, goods_number, customer_name, customer_mobile, customer_address from '.$wpdb->prefix . $config['common']['order_table_name'].' where out_trade_no = "'.$out_trade_no.'" limit 1 for update';
    $row = $wpdb->get_row( $sql, ARRAY_A);

    if($row['state']) {
        
        $mysqli->rollback();
        echo $respone;
    }else {
        $data = array();
        $data['action'] = 'Notify';
        $data['data']['out_trade_no'] = $out_trade_no;
        $data['data']['pluginid'] = $options['pluginid'];
        $data['data']['has_order_sms'] = $common_options['has_order_sms'];
        $data['data']['customer_name'] = $row['customer_name'];
        $data['data']['customer_mobile'] = $row['customer_mobile'];
        $data['data']['customer_address'] = $row['customer_address'];
        $data['data']['total_fee'] = $row['total_fee'];

        $result = \Weixin\MyFunctions::get_web($url, $data);
        $result = json_decode($result, true);
        if(0 == $result['errno']) {
            $order_table = $wpdb->prefix . $config['common']['order_table_name'];
            $goods_meta = $wpdb->prefix . $config['common']['goods_meta_table_name'];

            $update_state = 'update ' . $order_table . ' set state = 1, notify_xml = "'.$xml.'", transaction_id = "'.$rs['transaction_id'].'" where out_trade_no = "'.$out_trade_no.'"';
            
            $update_stock = 'update ' . $goods_meta . ' set goods_stock = goods_stock - '.$row['goods_number'].' where post_id = ' . $row['post_id'];

            $rs1 = $mysqli->query($update_state);
            $rs2 = $mysqli->query($update_stock);
            if(! $rs1 || ! $rs2) {
                $mysqli->rollback();
            }else {
                $mysqli->commit();
                echo $respone;
            }

            if(isset($result['db_data'])) {
                global $wpdb;
                $table_name = $wpdb->prefix . $config['common']['sms_table_name'];
                $wpdb->insert($table_name, $result['db_data']);
            }

        }else {
            $mysqli->rollback();
        }
    }
    $mysqli->close();
}
