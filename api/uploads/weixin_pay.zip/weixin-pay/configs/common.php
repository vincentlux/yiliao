<?PHP
/*
 +----------------------------------------------------------------------+
 | common config                                                        |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:42:51                                  |
 | 警告：          不要随意修改这里的配置，可能导致支付功能无法使用     |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$config = array(
    'debug' => false,
    'plugin_name' => 'weixin-pay',
    'page_slug' => 'weixin_pay',
    'tpl_dir' => 'tpl',
    'request_uri' => 'https://www.qinziheng.com/api/wordpress_weixin_pay',
    'pay_file' => 'pay.php',
    'cookie_key' => 'daqin_weixin_pay',
    'token_cookie_key' => 'daqin_weixin_token',
    'cookie_encrypt_key' => '{{cookie_encrypt_key}}',
    'notify_file' => 'notify.php',
    'order_expire' => '300',
    'goods_meta_table_name' => 'daqin_weixin_pay_goods_meta',
    'order_table_name' => 'daqin_weixin_pay_order',
    'sms_table_name' => 'daqin_weixin_pay_sms',
    'token_table_name' => 'daqin_weixin_pay_token',
    'mobile_code_expire' => 300,
    'user_info_cookie_key' => 'daqin_weixin_pay_user',
    'user_info_expire' => 604800,
    'expire_month' => 2592000,
    'page_per_number' => 10,
    'modify_count' => 6,
    'order_trigger_vcode' => 100,
);

return $config;
