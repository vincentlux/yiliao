<?PHP
/*
 +----------------------------------------------------------------------+
 | goodsmeta config                                                     |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:43:16                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$config = array(
    'goods_name' => '_daqin_weixin_pay_goods_name',
    'goods_price' => '_daqin_weixin_pay_goods_price',
    'goods_stock' => '_daqin_weixin_pay_goods_stock',
    'goods_meta' => '_daqin_weixin_pay_goods_meta',
);

return $config;
