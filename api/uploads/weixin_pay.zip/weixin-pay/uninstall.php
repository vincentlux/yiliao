<?php
/*
 +----------------------------------------------------------------------+
 | uninstall daqin weixin pay plugin                                    |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:42:13                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
 
if( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit();
}
 
$options = get_option('daqin_weixin_pay_common');
$options = unserialize($options);
if($options['clear_data']) {
    delete_option( 'daqin_weixin_pay_common' );
    delete_option( 'daqin_weixin_pay_register' );
    delete_option( 'daqin_weixin_pay_pluginid' );

    global $wpdb;
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}daqin_weixin_pay_goods_meta" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}daqin_weixin_pay_order" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}daqin_weixin_pay_sms" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}daqin_weixin_pay_token" );
    setcookie('daqin_weixin_pay', '', (time() - 60), '/');
    setcookie('daqin_weixin_token', '', (time() - 60), '/');
    setcookie('daqin_weixin_pay_user', '', (time() - 60), '/');
}
 
 
 
