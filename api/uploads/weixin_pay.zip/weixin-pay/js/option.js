function check_pay_option(data, msgid) {
    return true;
}
jQuery(document).ready(function(){

    jQuery('#save-pay').click(function() {
        var data = {};
        data['name'] = jQuery("#name").val();
        data['mobile'] = jQuery("#mobile").val();
        data['mobile_code'] = jQuery("#mobile-code").val();
        data['domain'] = jQuery("#domain").val();
        data['appid'] = jQuery("#appid").val();
        data['appsecret'] = jQuery("#appsecret").val();
        data['mchid'] = jQuery("#mchid").val();
        data['mchkey'] = jQuery("#mchkey").val();
        data['pluginid'] = jQuery("#pluginid").val();

        var action = 'SavePay';
        var msgid = '#pay-msg';
        subdata(action, data, msgid);
    });

    jQuery('#save-option').click(function() {
        var data = {};
        data['warn_stock'] = jQuery("#warn-stock").val();
        data['has_address'] = jQuery("input[name='has_address']:checked").val();
        data['has_remark'] = jQuery("input[name='has_remark']:checked").val();
        data['has_vcode'] = jQuery("input[name='has_vcode']:checked").val();
        data['has_name'] = jQuery("input[name='has_name']:checked").val();
        data['has_mobile'] = jQuery("input[name='has_mobile']:checked").val();
        data['has_h5pay'] = jQuery("input[name='has_h5pay']:checked").val();
        data['check_mobile'] = jQuery("input[name='check_mobile']:checked").val();
        data['has_order_sms'] = jQuery("input[name='has_order_sms']:checked").val();
        data['clear_data'] = jQuery("input[name='clear_data']:checked").val();

        var action = 'SaveOption';
        var msgid = '#option-msg';
        subdata(action,data, msgid);
    });
    jQuery('#clear-data').click(function() {
        if(! confirm("慎用！选择 是 将删除所有订单数据!")) {
            return false;
        }
    });
    jQuery('#check-mobile').click(function() {
        var data = {};
        data['mobile_code'] = jQuery("#mobile-code").val();
        data['mobile'] = jQuery("#mobile").val();
        data['pluginid'] = jQuery("#pluginid").val();

        var action = 'CheckRegisterMobile';
        var msgid = '#pay-msg';
        subdata(action, data, msgid);
    });
});
