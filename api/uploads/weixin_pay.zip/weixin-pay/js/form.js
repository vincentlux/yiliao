function check_pay_option(data, msgid) {
    return true;
}
jQuery(document).ready(function(){
        jQuery('#submit').click(function() {
            var data = {};
            var action = 'SubmitOrder';
            var msgid = '#submit-msg';
            data['name'] = jQuery("#name").val();
            data['mobile'] = jQuery("#mobile").val();
            data['goods_number'] = jQuery("#goods_number").val();
            data['goods_price'] = jQuery("#goods_price").val();
            data['address'] = jQuery("#address").val();
            data['remark'] = jQuery("#remark").val();
            data['vcode'] = jQuery("#vcode").val();
            data['mobile_code'] = jQuery("#mobile-code").val();

            if (typeof WeixinJSBridge == "undefined"){
                data['is_weixin'] = 0;
            }else {
                data['is_weixin'] = 1;
            }
            subdata(action, data, msgid);
        });

        jQuery('#check-mobile').click(function() {
            var data = {};
            var action = 'CheckMobile';
            var msgid = '#submit-msg';
            data['mobile'] = jQuery("#mobile").val();
            data['vcode'] = jQuery("#vcode").val();
            subdata(action, data, msgid);
        });

        jQuery('#clear-cookie').click(function() {
            var data = {};
            var action = 'ClearCookie';
            var msgid = '#submit-msg';
            subdata(action, data, msgid);
        });
});
