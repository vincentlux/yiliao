<?php
/*
 +----------------------------------------------------------------------+
 | submit pay                                                           |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:04:53                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */

require( '../../../wp-load.php' );
ini_set('date.timezone','Asia/Shanghai');

$config = \Weixin\Factory::getConfig(DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'configs');
$order_data = $_COOKIE[$config['common']['cookie_key']];
$order_data = unserialize(stripslashes(\Weixin\MyFunctions::myDecrypt($order_data, $config['common']['cookie_encrypt_key'])));

if(! isset($order_data['goods_number']) && $order_data['goods_number'] < 1) {
    exit('请重新下单');
}

if( (boolean) $order_data['is_weixin'] || \Weixin\MyFunctions::is_weixin()) {
    $options = get_option($config['options']['register']);
    $options = unserialize($options);
    $options['appsecret'] = \Weixin\MyFunctions::myDecrypt($options['appsecret'], $config['common']['cookie_encrypt_key']);
    $options['mchkey'] = \Weixin\MyFunctions::myDecrypt($options['mchkey'], $config['common']['cookie_encrypt_key']);

    $openid = $_COOKIE[$config['common']['token_cookie_key']];
    $openid = \Weixin\MyFunctions::myDecrypt($openid, $config['common']['cookie_encrypt_key']);

    if($openid) {

        global $wpdb;
        $token_table = $wpdb->prefix . $config['common']['token_table_name'];
        $sql = 'select access_token, refresh_token, end_time from ' . $token_table . ' where openid = "'.$openid.'" order by id desc limit 1';
        $row = $wpdb->get_row($sql, ARRAY_A);

        if($row) {
            $check_result = \Weixin\JsApiPay::check_token($row['access_token'], $openid);
            if(0 == $check_result['errcode']) {
                echo 'old openid<br />';
                \Weixin\MyFunctions::create_jspay($openid, false, $options, $order_data);
            }else {
                $reget_token = \Weixin\JsApiPay::reget_access_token($options['appid'], $row['refresh_token']);
                if(isset($reget_token['openid'])) {
                    echo 'openid from refresh token<br />';
                    \Weixin\MyFunctions::create_jspay($reget_token['openid'], true, $options, '', $reget_token);
                }else {
                    if(isset($_GET['code'])) {
                        $rs_a = \Weixin\JsApiPay::get_auth_token_from_weixin($options['appid'], $options['appsecret'], $_GET['code']);

                        if(isset($rs_a['openid'])) {
                            \Weixin\MyFunctions::create_jspay($rs_a['openid'], true, $options, '', $rs_a);
                        }else {
                            echo json_encode($rs_a);
                        }
                        
                    }else {
                        $url = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
                        $url = \Weixin\JsApiPay::create_auth_url($options['appid'], $url);
                        header('location:' . $url);
                    }
                }
            }
        }else {
            if(isset($_GET['code'])) {
                $rs_a = \Weixin\JsApiPay::get_auth_token_from_weixin($options['appid'], $options['appsecret'], $_GET['code']);

                if(isset($rs_a['openid'])) {
                    \Weixin\MyFunctions::create_jspay($rs_a['openid'], true, $options, '', $rs_a);
                }else {
                    echo json_encode($rs_a);
                }
                
            }else {
                $url = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
                $url = \Weixin\JsApiPay::create_auth_url($options['appid'], $url);
                header('location:' . $url);
            }
        }

    }else {

        if(isset($_GET['code'])) {
            $rs_a = \Weixin\JsApiPay::get_auth_token_from_weixin($options['appid'], $options['appsecret'], $_GET['code']);

            if(isset($rs_a['openid'])) {
                echo 'openid from weixin<br />';
                \Weixin\MyFunctions::create_jspay($rs_a['openid'], true, $options, '', $rs_a);
            }else {
                echo json_encode($rs_a);
            }
            
        }else {
            $url = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
            $url = \Weixin\JsApiPay::create_auth_url($options['appid'], $url);
            header('location:' . $url);
        }
    }

}else {


    $order = new \Weixin\CreateOrder($order_data, DAQIN_WEIXIN_PAY_PLUGIN_DIR);

    if(wp_is_mobile()) {
        $options = get_option($config['options']['common']);
        $options = unserialize($options);

        if($options['has_h5pay']) {
            $result = $order->h5pay();
            $result = json_decode($result, true);
            
            $res = \Weixin\UnifiedOrder::wxpay($result['data']['xml'], $result['data']['mchkey']);
            if(isset($res['mweb_url'])) {
                global $wpdb;
                $table_name = $wpdb->prefix . $config['common']['order_table_name'];
                $wpdb->insert($table_name, $result['db_data']);
                setcookie($_COOKIE[$config['common']['cookie_key']], '', (time() - 60), '/');

                session_start();
                $mobile_session_key = $result['db_data']['customer_mobile'] . '_code';
                if(isset($_SESSION[$mobile_session_key])) {
                    $mobile_session_expire_key = $result['db_data']['customer_mobile'] . '_expire';
                    unset($_SESSION[$mobile_session_key]);
                    unset($_SESSION[$mobile_session_expire_key]);
                }

                header('Location:' . $res['mweb_url']);
            }
        }
    }else {

            $result = $order->native();
            $result = json_decode($result, true);

            $res = \Weixin\UnifiedOrder::wxpay($result['data']['xml'], $result['data']['mchkey']);
            if(isset($res['code_url'])) {
                global $wpdb;
                $table_name = $wpdb->prefix . $config['common']['order_table_name'];
                $wpdb->insert($table_name, $result['db_data']);
                setcookie($_COOKIE[$config['common']['cookie_key']], '', (time() - 60), '/');

                session_start();
                $mobile_session_key = $result['db_data']['customer_mobile'] . '_code';
                if(isset($_SESSION[$mobile_session_key])) {
                    $mobile_session_expire_key = $result['db_data']['customer_mobile'] . '_expire';
                    unset($_SESSION[$mobile_session_key]);
                    unset($_SESSION[$mobile_session_expire_key]);
                }

                $errorCorrectionLevel = 'M';
                $matrixPointSize = 8;
                $margin = 2;
                $saveandprint = false;

                $image_name = 'images/qrcode_' . date('YmdHis') . '-' . mt_rand(100000,999999) . '.png';
                $image_path = DAQIN_WEIXIN_PAY_PLUGIN_DIR . $image_name;
                $image_url = DAQIN_WEIXIN_PAY_PLUGIN_URL . $image_name;
                \Weixin\QRcode::png($res['code_url'],$image_path , $errorCorrectionLevel, $matrixPointSize, $margin, $saveandprint);
            }

        include DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'tpl/native.htm';
    }

}
