<?PHP
/*
 +----------------------------------------------------------------------+
 | My error                                                             |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:47:12                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class MyError {
    const SUCCESS_NO = 0;
    const SUCCESS_MSG = 'ok';

    const NAME_ERRNO = 400001;
    const NAME_ERRMSG = 'name invalid';

    const MOBILE_ERRNO = 400002;
    const MOBILE_ERRMSG = 'mobile invalid';

    const MOBILE_CODE_ERRNO = 400003;
    const MOBILE_CODE_ERRMSG = 'mobile code invalid';

    const MOBILE_CODE_EXPIRE_ERRNO = 400004;
    const MOBILE_CODE_EXPIRE_ERRMSG = 'mobile code be expired';

    const VCODE_ERRNO = 400005;
    const VCODE_ERRMSG = 'check code invalid';

    const DB_UPDATE_ERRNO = 400051;
    const DB_UPDATE_ERRMSG = 'no save';

    const PLUGINDID_ERRNO = 400052;
    const PLUGINDID_ERRMSG = 'plugind insert into options fail';

    const GOODS_NUMBER_ERRNO = 400061;
    const GOODS_NUMBER_ERRMSG = 'goods number invalid';

    const ADDRESS_ERRNO = 400071;
    const ADDRESS_ERRMSG = 'address invalid';

    const COOKIE_ERRNO = 400075;
    const COOKIE_ERRMSG = 'cookie can not use';

    const CLEAR_COOKIE_ERRNO = 400076;
    const CLEAR_COOKIE_ERRMSG = 'cookie clear fail';

    const GOODS_PRICE_ERRNO = 400081;
    const GOODS_PRICE_ERRMSG = 'goods price change';

    const STOCK_LESS_ERRNO = 400082;
    const STOCK_LESS_ERRMSG = 'goods stock less';

    const ORDER_NOPAY_ERRNO = 400091;
    const ORDER_NOPAY_ERRMSG = 'order no pay';

    const ORDER_WEIXIN_ERRNO = 400092;
    const ORDER_WEIXIN_ERRMSG = 'weixin order error';

}
