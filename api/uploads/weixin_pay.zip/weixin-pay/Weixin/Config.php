<?PHP
/*
 +----------------------------------------------------------------------+
 | config                                                               |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:04:53                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class Config implements \ArrayAccess{
    protected $path;
    protected $configs = array();

    /**
     *
     *      @param  $path   string  配置文件所在路径
     *
     */
    function __construct($path) {
        $this->path = $path;
    }

    /**
     *
     *      获取数组的 key
     *
     */
    function offsetGet($key) {
        if(empty($this->configs[$key])) {
            $file_path = $this->path . '/' . strtolower($key) . '.php';
            
            $config = require $file_path;
            $this->configs[$key] = $config;
        }

        return $this->configs[$key];
    }

    /**
     *
     *      设置数组的 key
     *
     */
    function offsetSet($key, $value) {
        throw new \Exception('can not write config file.');
    }

    function offsetExists($key) {
        return isset($this->configs[$key]);
    }

    function offsetUnset($key) {
        unset($this->configs[$key]);
    }
}
