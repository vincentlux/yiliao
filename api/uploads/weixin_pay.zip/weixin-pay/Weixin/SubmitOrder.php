<?PHP
/*
 +----------------------------------------------------------------------+
 | submit order                                                         |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:54:05                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class SubmitOrder  {
    protected $config;
    private $url = '';
    private $data = array();

    function __construct($action, $base_dir) {
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');
        $this->action = $action;
    }

    function run($parameters) {
        $this->data = $parameters;
        $rs = $this->check();
        if(0 == $rs['errno']) {
            $res = array();
            $res['errno'] = 0;
            $res['errmsg'] = 'ok';
            $res['url'] = DAQIN_WEIXIN_PAY_PLUGIN_URL . $this->config['common']['pay_file'];

            $cookie = \Weixin\MyFunctions::myCrypt(serialize($rs['data']), $this->config['common']['cookie_encrypt_key']);
            $time_expire = time() + 300;
            setcookie($this->config['common']['cookie_key'], $cookie, $time_expire, '/');

            $user_info = array();
            $user_info['name'] = $rs['data']['name'];
            $user_info['mobile'] = $rs['data']['mobile'];
            $user_info['address'] = $rs['data']['address'];
            $user_info_string = \Weixin\MyFunctions::myCrypt(serialize($user_info), $this->config['common']['cookie_encrypt_key']);
            $user_info_expire = time() + $this->config['common']['user_info_expire'];
            setcookie($this->config['common']['user_info_cookie_key'], $user_info_string, $user_info_expire, '/');

            if(! wp_is_mobile() && ! $rs['data']['is_weixin']) {
                $res['is_native'] = 1;
            }

            return json_encode($res);
        }else {
            return json_encode($rs);
        }
    }

    private function get_key($key) {
        if (isset($this->data[$key])) {
            $farr = array(
                "/<(\/?)(select|delete|update|union|join|script|i?frame|style|html|body|title|link|meta|\?|\%)([^>]*?)>/isU");
            $value = trim($this->data[$key]);
            $value = strip_tags($value);
            $value = preg_replace($farr,'',$value);
            $value = addslashes($value);
            $value = str_replace(array('gcd'), '', $value);
            return $value;
        }else {
            return false;
        }

    }

    private function check() {
        $res = $db_data = array();
        $res['errno'] = 0;
        $res['errmsg'] = 'ok';

        $this->data['gid'] = $this->get_key('gid');
        $options = get_option($this->config['options']['common']);
        $options = unserialize($options);

        $vcode = $this->get_key('vcode');
        if(false !== $vcode) {
            session_start();
            $prefix = \Weixin\MyFunctions::IP(true);
            $vcode_index = $prefix . '_code';
            if(strtoupper($vcode) != $_SESSION[$vcode_index]) {
                $res['errno'] = \Weixin\MyError::VCODE_ERRNO;
                $res['errmsg'] = \Weixin\MyError::VCODE_ERRMSG;
                return $res;
            }
        }

        if($options['has_mobile']) {
            $this->data['mobile'] = $this->get_key('mobile');
            if(! \Weixin\Check::is_mobile($this->data['mobile'])) {
                $res['errno'] = \Weixin\MyError::MOBILE_ERRNO;
                $res['errmsg'] = \Weixin\MyError::MOBILE_ERRMSG;
                return $res;
            }

            if($options['check_mobile']) {
                $mobile_code = $this->get_key('mobile_code');
                session_start();
                $session_index = $this->data['mobile'] . '_code';
                $mobile_code_session = $_SESSION[$session_index];

                $session_expire_index = $this->data['mobile'] . '_expire';
                $session_expire = $_SESSION[$session_expire_index];

                if(! $mobile_code || ! $mobile_code_session) {
                    $res['errno'] = \Weixin\MyError::MOBILE_CODE_ERRNO;
                    $res['errmsg'] = \Weixin\MyError::MOBILE_CODE_ERRMSG;
                    return $res;
                }

                if($mobile_code != $mobile_code_session) {
                    $res['errno'] = \Weixin\MyError::MOBILE_CODE_ERRNO;
                    $res['errmsg'] = \Weixin\MyError::MOBILE_CODE_ERRMSG;
                    return $res;
                }
            }
        } else {
            $this->data['mobile'] = '';
        }

        if($options['has_name']) {
            $this->data['name'] = $this->get_key('name');
            if(! \Weixin\Check::string_in_length($this->data['name'], 2, 10)) {
                $res['errno'] = \Weixin\MyError::NAME_ERRNO;
                $res['errmsg'] = \Weixin\MyError::NAME_ERRMSG;
                return $res;
            }
        }else {
            $this->data['name'] = '';
        }

        global $wpdb;
        $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
        $sql = 'select goods_name, goods_price, goods_stock from '.$goods_meta_table.' where post_id = '.$this->data['gid'].' order by id desc limit 1';
        $goods_meta = $wpdb->get_row($sql, ARRAY_A);

        $this->data['goods_name'] = $goods_meta['goods_name'];
        $this->data['goods_number'] = intval($this->get_key('goods_number'));
        if(! is_numeric($this->data['goods_number']) || $this->data['goods_number'] < 1) {
            $res['errno'] = \Weixin\MyError::GOODS_NUMBER_ERRNO;;
            $res['errmsg'] = \Weixin\MyError::GOODS_NUMBER_ERRMSG;;
            return $res;
        }

        if($this->data['goods_number'] > $goods_meta['goods_stock']) {
            $res['errno'] = \Weixin\MyError::STOCK_LESS_ERRNO;;
            $res['errmsg'] = \Weixin\MyError::STOCK_LESS_ERRMSG;;
            return $res;
        }

        if($options['has_address']) {
            $this->data['address'] = $this->get_key('address');
            if(mb_strlen($this->data['address']) < 5) {
                $res['errno'] = \Weixin\MyError::ADDRESS_ERRNO;
                $res['errmsg'] = \Weixin\MyError::ADDRESS_ERRMSG;
                return $res;
            }
        }else {
            $this->data['address'] = '';
        }

        $this->data['goods_price'] = intval($this->get_key('goods_price') * 100);
        if($this->data['goods_price'] != $goods_meta['goods_price']) {
            $res['errno'] = \Weixin\MyError::GOODS_PRICE_ERRNO;
            $res['errmsg'] = \Weixin\MyError::GOODS_PRICE_ERRMSG;
            return $res;
        }

        $this->data['remark'] = $this->get_key('remark');
        if(! $this->data['remark']) {
            $this->data['remark'] = '';
        }

        $this->data['is_weixin'] = $this->get_key('is_weixin');
        $this->data['ip'] = $this->get_key('ip');

        $res['data'] = $this->data;
        return $res;
    }
}
