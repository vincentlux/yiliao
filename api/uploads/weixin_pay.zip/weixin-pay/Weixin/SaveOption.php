<?PHP
/*
 +----------------------------------------------------------------------+
 | save option                                                          |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:52:26                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class SaveOption  {
    protected $config;
    private $option_key = '';
    private $data = array();

    function __construct($action, $base_dir) {
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');
        $this->option_key = $this->config['options']['common'];
    }

    function run($parameters) {
        $this->data = $parameters;
        $rs = $this->check();
        if(0 == $rs['errno']) {
                if(! update_option($this->option_key, serialize($rs['data']), 'no')) {
                    $rs['errno'] = \Weixin\MyError::DB_UPDATE_ERRNO;
                    $rs['errmsg'] = \Weixin\MyError::DB_UPDATE_ERRMSG;
                }
                unset($rs['data']);
                return json_encode($rs);
        }else {
            return json_encode($rs);
        }
    }

    private function get_key($key) {
        if (isset($this->data[$key])) {
            $value = trim($this->data[$key]);
            $value = strip_tags($value);
            $value = addslashes($value);
            return $value;
        }else {
            return false;
        }
    }

    private function check() {
        $res = $db_data = array();
        $res['errno'] = 0;
        $res['errmsg'] = 'ok';

        $db_data['warn_stock'] = intval($this->get_key('warn_stock'));
        $db_data['has_address'] = $this->get_key('has_address');
        $db_data['has_remark'] = $this->get_key('has_remark');
        $db_data['has_vcode'] = $this->get_key('has_vcode');
        $db_data['has_name'] = $this->get_key('has_name');
        $db_data['has_mobile'] = $this->get_key('has_mobile');
        $db_data['has_h5pay'] = $this->get_key('has_h5pay');
        $db_data['check_mobile'] = $this->get_key('check_mobile');
        $db_data['has_order_sms'] = $this->get_key('has_order_sms');
        $db_data['clear_data'] = $this->get_key('clear_data');

        $res['data'] = $db_data;
        return $res;
    }
}
