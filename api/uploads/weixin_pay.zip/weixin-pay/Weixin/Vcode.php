<?PHP
    /**
     *
     *      验证码
     *          113 行 fontStyle = 'msyhbd.ttf'; 指定字体路径
     *
     *
     *      使用方法：
               1.新建一个vcode.php文件，代码
                       引入vcode.class.php
                       session_start();
                       $vcode = new Vcode();
                       //echo $_SESSION['code'];
                       $vcode->__toString();
                2.验证码会保存在$_SESSION['code']中
                3.在要使用验证码的网页加入下面代码，其中src中设置vcode的路径
                    <img   src="./vcode.php"  onclick="this.src='vcode.php?'+Math.random();">
     *
     *
     */
namespace Weixin;
    class Vcode{
        private $width;             //验证码图片的宽度
        private $height;            //验证码图片的高度
        private $codeNum;           //验证码字符的个数
        private $checkCode;         //验证码字符
        private $image;             //验证码资源
        private $font_path;             // font 字体路径
        private $prefix;             // session code 前缀

        /**
         *
		 * 构造方法用来实例化验证码对象，并为一些成员属性初使化       
		 * @param	int	$width		设置验证码图片的宽度，默认宽度值为80像素        
		 * @param	int	$height		设置验证码图片的高度，默认高度值为20像素       
		 * @param	int	$codeNum	设置验证码中字母和数字的个数，默认个数为4个  
         *
		 */ 
        function __construct($width = 120, $height = 40, $codeNum = 4, $font_path = '', $prefix = '') {
            $this->width = $width;
            $this->height = $height;
            $this->codeNum = $codeNum;
            $this->font_path = $font_path;
            $this->prefix = $prefix;

            $this->checkCode = $this->createCheckCode();
        }

        /**
         *
         *  生成指定个数和字符串，去年容易混淆的字符oOLlz和数字012
         *  return  string
         *
         */
        private function createCheckCode() {
            $code = '3456789abcdefghijkmnpqrstuvwxyABCDEFGHIJKMNPQRSTUVWXY';
            return substr(str_shuffle($code), 0, $this->codeNum);
        }

        /**
         *
		 * 用于输出验证码图片，也向服务器的SESSION中保存了验证码
		 * 使用echo 输出对象即可
		 * @return string	验证码
         *
		 */
        function __toString() {
            $session_index = $this->prefix . 'code';
            $_SESSION[$session_index] = strtoupper($this->checkCode);
            //echo $this->checkCode, '<br />';
            //echo $_SESSION['code'], '<br />';
            $this->outImg();
            return '';
        }

        private function outImg() {
            $this->getCreateImage();                 //调用内部方法创建画布并对其进行初使化
			$this->setDisturbColor();                 //向图像中设置一些干扰像素
			$this->outputText();                     //向图像中输出随机的字符串
			$this->outputImage();                    //生成相应格式的图像并输出
        }

        /**
         *
         *      创建图像资源，并初始化背景
         *
         *
         */
        private function getCreateImage() {
            $this->image = imagecreatetruecolor($this->width, $this->height);
            $backColor = imagecolorallocate($this->image, 255, 255, 255);
            @imagefill($this->image, 0, 0, $backColor);

            $border = imageColorAllocate($this->image, 0, 0, 0);
            imageRectangle($this->image, 0, 0, $this->width - 1, $this->height-1, $border);

        }

        /**
         *
         *      3条直线进行干扰
         *
         *
         */
        private function setDisturbColor() {
            for($i = 0; $i<3; $i++) {
                $color = imagecolorallocate($this->image, rand(0, 128), rand(0, 128), rand(0, 128));
                imageline ( $this->image , 0 , rand((($this->height / 2) - 10), (($this->height / 2) + 10)) , $this->width , rand((($this->height / 2) - 10), (($this->height / 2) + 10)) , $color );
            }
        }

        /**
         *
         *      输出字符串
         *
         *
         */
        private function outputText() {
            //$fontStyle = 'franchise.ttf';
            $fontStyle = $this->font_path;
            //$fontStyle = 'consolas';
            for($i = 0; $i < $this->codeNum; $i++) {
                $fontcolor = imagecolorallocate($this->image, rand(0, 128), rand(0, 128), rand(0, 128));
                $fontSize = rand(20, 25);   // 字体大小
                //echo $fontSize, '<br />';
                $x = floor($this->width / $this->codeNum) * $i + 5;
                //$y = rand(floor(imagefontheight($fontSize) * 1.8), floor(imagefontheight($fontSize) * 3));
                $y = rand(imagefontheight($fontSize) * 2, $this->height-imagefontheight($fontSize));
                //$y = rand(0, $this->height-imagefontheight($fontSize)); // imagefontheight($fontSize) 是一个固定值， 这里为 15
                //echo imagefontheight($fontSize), '<br />';  // 15
                //echo imagefontwidth($fontSize), '<br />';   // 9
                imagettftext($this->image, $fontSize, 0, $x, $y, $fontcolor, $fontStyle, $this->checkCode{$i}); // x, y 是定义左下角的位置
            }
            //exit;
        }

        private function outputImage() {
            ob_clean();
            if(imagetypes() & IMG_GIF) {
                header("Content-type: image/gif");  //发送标头信息设置MIME类型为image/gif
				imagegif($this->image);           //以GIF格式将图像输出到浏览器
            }elseif(imagetypes() & IMG_JPG) {
                header("Content-type: image/jpeg");  //发送标头信息设置MIME类型为image/jpeg
				imagejpeg($this->image, '', 0,5);           //以GIF格式将图像输出到浏览器
            }elseif(imagetypes() & IMG_PNG) {
                header("Content-type: image/png");  //发送标头信息设置MIME类型为image/png
				imagepng($this->image);           //以GIF格式将图像输出到浏览器
            }elseif(imagetypes() & IMG_WBMP) {
                header("Content-type: image/vnd.wap.wbmp");  //发送标头信息设置MIME类型为image/wbmp
				imagewbmp($this->image);           //以GIF格式将图像输出到浏览器
            }else {
                die('此版本不支持创建图片！');
            }

        }

        function __destruct() {
            if ( $this->image ) {
                imagedestroy($this->image);     // 调用GD库中的方法销毁图像资源
            }
        }

    }

    //$vcode = new Vcode();
    //$vcode->__toString();
