<?PHP
/*
 +----------------------------------------------------------------------+
 | weixin pay                                                           |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 16:04:53                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class CheckRegisterMobile  {
    protected $config;
    private $url = '';
    private $data = array();
    private $action = '';

    function __construct($action, $base_dir) {
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');
        $this->action = $action;
        $this->url = $this->config['common']['request_uri'] . '/wepay.php';
    }

    function run($parameters) {
        $this->data = $parameters;
        $rs = $this->check();
        if(0 == $rs['errno']) {
            $option = array();
            $option['action'] = $this->action;
            $option['data']['mobile'] = $this->data['mobile'];
            $option['data']['pluginid'] = $this->data['pluginid'];

            $result = \Weixin\MyFunctions::get_web($this->url, $option);

            $result_a = json_decode($result, true);
            if(0 == $result_a['errno']) {

                session_start();
                $session_code_key = $result_a['db_data']['mobile'] . '_code';
                $session_expire = $result_a['db_data']['create_time'] + $this->config['common']['mobile_code_expire'];
                $_SESSION[$session_code_key] = $result_a['data']['code'];
                $session_expire_key = $result_a['db_data']['mobile'] . '_expire';
                $_SESSION[$session_expire_key] = $session_expire;

                if(isset($result_a['db_data'])) {
                    unset($result_a['db_data']);
                }

                if(isset($result_a['data'])) {
                    unset($result_a['data']);
                }
                $result = json_encode($result_a);
            }
            return $result;
        }else {
            return json_encode($rs);
        }
    }

     private function get_key($key) {
        if (isset($this->data[$key])) {
            $farr = array(
                "/<(\/?)(select|delete|update|union|join|script|i?frame|style|html|body|title|link|meta|\?|\%)([^>]*?)>/isU");
            $value = trim($this->data[$key]);
            $value = strip_tags($value);
            $value = preg_replace($farr,'',$value);
            $value = addslashes($value);
            $value = str_replace(array('gcd'), '', $value);
            return $value;
        }else {
            return false;
        }

    }

    private function check() {
        $res = $db_data = array();
        $res['errno'] = 0;
        $res['errmsg'] = 'ok';

        $this->data['mobile'] = $this->get_key('mobile');
        if(! \Weixin\Check::is_mobile($this->data['mobile'])) {
            $res['errno'] = \Weixin\MyError::MOBILE_ERRNO;
            $res['errmsg'] = \Weixin\MyError::MOBILE_ERRMSG;
            return $res;
        }
        $this->data['pluginid'] = $this->get_key('pluginid');

        $res['data'] = $this->data;
        return $res;
    }
}
