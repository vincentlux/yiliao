<?PHP
/*
 +----------------------------------------------------------------------+
 | save pay                                                             |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:53:45                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class SavePay  {
    protected $config;
    private $url = '';
    private $option_key = '';
    private $data = array();

    function __construct($action, $base_dir) {
        session_start();
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');
        $this->action = $action;
        $this->url = $this->config['common']['request_uri'] . '/wepay.php';
        $this->option_key = $this->config['options']['register'];
        $this->option_pluginid_key = $this->config['options']['pluginid'];
    }

    function run($parameters) {
        $this->data = $parameters;
        $rs = $this->check($parameters);
        if(0 == $rs['errno']) {
            
            $rs['data']['plugin_url'] = DAQIN_WEIXIN_PAY_PLUGIN_URL;

            $option = array();
            $option['action'] = $this->action;
            $option['data'] = $rs['data'];
            $result = \Weixin\MyFunctions::get_web($this->url, $option);

            $result_a = json_decode($result, true);
            if(0 == $result_a['errno']) {
                $result_a['db_data']['appsecret'] = \Weixin\MyFunctions::myCrypt($rs['data']['appsecret'], $this->config['common']['cookie_encrypt_key']);
                $result_a['db_data']['mchkey'] = \Weixin\MyFunctions::myCrypt($rs['data']['mchkey'], $this->config['common']['cookie_encrypt_key']);
                $result_a['db_data']['mchid'] = \Weixin\MyFunctions::myCrypt($result_a['db_data']['mchid'], $this->config['common']['cookie_encrypt_key']);
                update_option($this->option_pluginid_key, $result_a['db_data']['pluginid'], 'no');
                if(! update_option($this->option_key, serialize($result_a['db_data']), 'no')) {
                    $result_a['errno'] = \Weixin\MyError::DB_UPDATE_ERRNO;
                    $result_a['errmsg'] = \Weixin\MyError::DB_UPDATE_ERRMSG;
                }

                $mobile_session_key = $this->data['mobile'] . '_code';
                if(isset($_SESSION[$mobile_session_key])) {
                    $mobile_session_expire_key = $this->data['mobile'] . '_expire';
                    unset($_SESSION[$mobile_session_key]);
                    unset($_SESSION[$mobile_session_expire_key]);
                }
            }
            if(isset($result_a['data'])) {
                unset($result_a['data']);
            }
            if(isset($result_a['db_data'])) {
                unset($result_a['db_data']);
            }
            return json_encode($result_a);
        }else {
            return json_encode($rs);
        }
    }

    private function get_key($key) {
        if (isset($this->data[$key])) {
            $farr = array(
                "/<(\/?)(select|delete|update|union|join|script|i?frame|style|html|body|title|link|meta|\?|\%)([^>]*?)>/isU");
            $value = trim($this->data[$key]);
            $value = strip_tags($value);
            $value = preg_replace($farr,'',$value);
            $value = addslashes($value);
            $value = str_replace(array('gcd'), '', $value);
            return $value;
        }else {
            return false;
        }

    }

    private function check($parameters) {
        $res = $db_data = array();
        $res['errno'] = 0;
        $res['errmsg'] = 'ok';

        $this->data['mobile'] = $this->get_key('mobile');
        if(! \Weixin\Check::is_mobile($this->data['mobile'])) {
            $res['errno'] = \Weixin\MyError::MOBILE_ERRNO;
            $res['errmsg'] = \Weixin\MyError::MOBILE_ERRMSG;
            return $res;
        }

        $mobile_code = $this->get_key('mobile_code');
        $session_index = $this->data['mobile'] . '_code';
        $mobile_code_session = $_SESSION[$session_index];

        $session_expire_index = $this->data['mobile'] . '_expire';
        $session_expire = $_SESSION[$session_expire_index];

        if(! $mobile_code || ! $mobile_code_session) {
            $res['errno'] = \Weixin\MyError::MOBILE_CODE_ERRNO;
            $res['errmsg'] = \Weixin\MyError::MOBILE_CODE_ERRMSG;
            return $res;
        }

        if($mobile_code != $mobile_code_session) {
            $res['errno'] = \Weixin\MyError::MOBILE_CODE_ERRNO;
            $res['errmsg'] = \Weixin\MyError::MOBILE_CODE_ERRMSG;
            return $res;
        }

        $res['data'] = $parameters;
        return $res;
    }
}
