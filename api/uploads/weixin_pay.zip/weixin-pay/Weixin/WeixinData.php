<?php
/*
 +----------------------------------------------------------------------+
 | weixin data                                                          |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:57:23                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;
class WeixinData
{
	public $values = array();

    /**
     *
     *      设置值
     *
     *
     */
    public function __set($key, $value) {
        $this->values[$key] = $value;
    }

    /**
     *
     *      获取值
     *
     *
     */
    public function __get($key) {
        return $this->values[$key];
    }

    /**
     *
     *      检测值，判断是否设置过
     *
     *
     */
    public function __isset($key) {
        return isset($this->values[$key]);
    }

    /**
     *
     *      array 2 xml
	 *          输出xml字符
     *
	**/
	public function array2xml()
	{
		if(!is_array($this->values) 
			|| count($this->values) <= 0)
		{
    		throw new Exception("数组数据异常！");
    	}
    	
    	$xml = "<xml>";
    	foreach ($this->values as $key=>$val)
    	{
    		if (is_numeric($val)){
    			$xml.="<".$key.">".$val."</".$key.">";
    		}else{
    			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
    		}
        }
        $xml.="</xml>";
        return $xml; 
	}

    /**
     *
     *      将xml转为array
     *          @param string $xml
     *
     */
	public function xml2array($xml)
	{	
		if(!$xml){
			throw new Exception("xml数据异常！");
		}
        libxml_disable_entity_loader(true);
        $this->values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
		return $this->values;
	}

    /**
	 *      把 array 转换成 url 请求的参数
	 */
	public function array2urlParam($arr)
	{
        
		$buff = "";
		foreach ($arr as $k => $v)
		{
			if($k != "sign" && $v != "" && !is_array($v)){
				$buff .= $k . "=" . $v . "&";
			}
		}
		
		$buff = trim($buff, "&");
		return $buff;
	}

    /**
	 * 生成签名
	 * @return 签名，本函数不覆盖sign成员变量，如要设置签名需要调用SetSign方法赋值
	 */
	public function makeSign($mch_key)
	{
		ksort($this->values);
		$string = $this->array2urlparam($this->values);
		$string = $string . "&key=".$mch_key;
		$string = md5($string);
		$result = strtoupper($string);
		return $result;
	}

    /**
	* 设置签名，详见签名生成算法
	* @param string $value 
	**/
	public function setSign($mch_key)
	{
		$sign = $this->makeSign($mch_key);
		$this->values['sign'] = $sign;
		return $sign;
	}

    

    /**
	 * 
	 * 产生随机字符串，不长于32位
	 * @param int $length
	 * @return 产生的随机字符串
	 */
	public function getNonceStr($length = 32) 
	{
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {  
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
		} 
		return $str;
	}

    /**
	 * 获取设置的值
	 */
	public function getValues()
	{
		return $this->values;
	}

    /**
     *
	 *      生成公众号支付
	 *      @return array    签名
     *
	 */
	public function makeJsSign($prepay_id = null, $appid, $mch_key)
	{
        if(! $prepay_id || empty($appid) || empty($mch_key)) {
            return false;
        }

        $time = time();
        $fields = array(
                'appId' => $appid,
                'timeStamp' => "$time",
                'nonceStr' => $this->getNonceStr(),
                'package' => 'prepay_id=' . $prepay_id,
                'signType' => 'MD5',
            );
		ksort($fields);
		$string = $this->array2urlparam($fields);
		$string = $string . "&key=".$mch_key;
		$string = md5($string);
		$result = strtoupper($string);

        $fields['paySign'] = $result;
		return $fields;
	}

    /**
	 * 
	 * 获取地址js参数
	 * 
	 * @return 获取共享收货地址js函数需要的参数，json格式可以直接做参数使用
	 */
	public function getAddress($appid, $access_token)
	{	
		$data = array();
		$data["appid"] = $appid;
		$data["url"] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$time = time();
		$data["timestamp"] = "$time";
		$data["noncestr"] = $this->getNonceStr();
		$data["accesstoken"] = $access_token;
		ksort($data);
		$params = $this->array2urlparam($data);
		$addrSign = sha1($params);
		
		$afterData = array(
			"addrSign" => $addrSign,
			"signType" => "sha1",
			"scope" => "jsapi_address",
			"appId" => $appid,
			"timeStamp" => $data["timestamp"],
			"nonceStr" => $data["noncestr"]
		);
		$parameters = json_encode($afterData);
		return $parameters;
	}
}
