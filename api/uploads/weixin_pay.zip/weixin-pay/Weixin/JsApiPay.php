<?php
/*
 +----------------------------------------------------------------------+
 | js api pay                                                           |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-05-05 16:06:03                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */

namespace Weixin;
class JsApiPay {
    /**
     *
     *      从微信获取 access token, refresh token, openid等信息
     *
     *          param       $code       string      code
     *          return      array()                 从微信获取到的信息 
     *
     *
     */
    static public function get_auth_token_from_weixin($appid, $appsecret, $code) {
            $url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $appid . '&secret=' . $appsecret . '&code=' . $code . '&grant_type=authorization_code';

            $rs_a = json_decode(\Weixin\MyFunctions::get_web($url), true);

            return $rs_a;
    }

        /**
         * 
         * 拼接字符串
         * @param array $urlObj
         * 
         * @return 返回已经拼接好的字符串
         */
        protected function get_url_params($urlObj)
        {
            $buff = "";
            foreach ($urlObj as $k => $v)
            {
                    $buff .= $k . "=" . $v . "&";
            }
            $buff = trim($buff, "&");

            return $buff;
        }
        /**
         * 
         * 构造获取code的url连接
         * @param string $redirectUrl 微信服务器回跳的url，需要url编码
         * 
         * @return 返回构造好的url
         */
        static public function create_auth_url($appid, $redirectUrl)
        {
            $urlObj["appid"] = $appid;
            $urlObj["redirect_uri"] = "$redirectUrl";
            $urlObj["response_type"] = "code";
            $urlObj["scope"] = "snsapi_base";
            $urlObj["state"] = "STATE"."#wechat_redirect";
            $bizString = self::get_url_params($urlObj);
            return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
        }

        /**
         * 
         *      检验 access token 有效性
         *          return array
         *              json_decode({ "errcode":0,"errmsg":"ok"}, true)
         * 
         */
        static public function check_token($access_token, $openid)
        {
            $url = 'https://api.weixin.qq.com/sns/auth?access_token='.$access_token.'&openid=' . $openid;
            return json_decode(\Weixin\MyFunctions::get_web($url), true);
        }

        /**
         * 
         *      refresh_token 重新获取 access token
         *          return array
         * 
         */
        static public function reget_access_token($appid, $refresh_token)
        {
            
            $url = 'https://api.weixin.qq.com/sns/oauth2/refresh_token?appid='.$appid.'&grant_type=refresh_token&refresh_token=' . $refresh_token;
            return json_decode(\Weixin\MyFunctions::get_web($url), true);
        }
}
