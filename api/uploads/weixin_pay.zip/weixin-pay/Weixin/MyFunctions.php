<?PHP
/*
 +----------------------------------------------------------------------+
 | my functions                                                         |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:47:40                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class MyFunctions {
    /* 
     *
     *      过滤数据
     *
     */
    static public function filter($key) {

            $farr = array(
                "/<(\/?)(select|delete|update|union|join|script|i?frame|style|html|body|title|link|meta|\?|\%)([^>]*?)>/isU");
            $value = trim($key);
            $value = strip_tags($value);
            $value = preg_replace($farr,'',$value);
            $value = addslashes($value);
            $value = str_replace(array('gcd'), '', $value);
            return $value;
    }

    /* 
     *
     *      从 $_GET 或者 $_POST 中获取元素
     *
     *
     */
    static public function get($key, $method = 'get') {
        $plist = $method == 'get' ? $_GET : $_POST;

        if (isset($plist[$key])) {
            $farr = array(
                "/<(\/?)(select|delete|update|union|join|script|i?frame|style|html|body|title|link|meta|\?|\%)([^>]*?)>/isU");
            $value = trim($plist[$key]);
            $value = strip_tags($value);
            $value = preg_replace($farr,'',$value);
            $value = addslashes($value);
            $value = str_replace(array('gcd'), '', $value);
            return $value;
        }else {
            return false;
        }
    }

    /*
     *      获取网页内容，包括https类型
     *          
     *          param   $url    string  网页的url
     *          parma   $post_a   array   post提交时的数据
     *
     *          return  string          utf-8型字符串
     *
     */
	static public function get_web($url, $post_a = null, $timeout = 20)
	{
        $https = substr($url, 0, 5);
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
        if ('https' == $https) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        }
		if (!empty($post_a)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post_a));
		}

		curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$string = curl_exec($curl);
        $char_a = array('GBK', 'GB2312', 'ASCII','UTF-8');
        $encode = mb_detect_encoding($string, $char_a);
        if ('UTF-8' != $encode && in_array($encode, $char_a)) {
            $string = mb_convert_encoding($string, 'UTF-8', $encode);
        }
        
		curl_close($curl);
		return $string;
	}

    static public function IP($longIP = false)
    {
     
            if(!empty($_SERVER["HTTP_CLIENT_IP"])){
              $cip = $_SERVER["HTTP_CLIENT_IP"];
            }
            elseif(!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
              $cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
            }
            elseif(!empty($_SERVER["REMOTE_ADDR"])){
              $cip = $_SERVER["REMOTE_ADDR"];
            }
            else{
              $cip = "";
            }
            if($longIP) {
                return sprintf("%u", ip2long($cip));
            }else {
                return $cip;
            }
    }

    static public function myCrypt($sStr, $sKey, $method = 'AES-256-ECB'){
        $str = openssl_encrypt($sStr,$method,$sKey);
        return urlencode($str);
    }

    static public function myDecrypt($sStr, $sKey, $method = 'AES-256-ECB'){
        $sStr = urldecode($sStr);
        $str = openssl_decrypt($sStr,$method,$sKey);
        return $str;
    }

    static public function rand_string($length = 32, $mix = false) 
	{
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
        if($mix) {
		    $chars = "abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";  
        }
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {  
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
		} 
		return $str;
	}


    static public function _crc32($data) { 
        return sprintf("%u", $data); 
    }
    
   function is_weixin() { 
        if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') !== false) { 
            return true;
        }
        return false; 
    } 

    /**
     *
     *      $order_data     array()     订单数据
     *      $options        array()     插件在 options 表中的数据
     *      $token_data     array()     网页授权返回的数据，保存到数据库
     *
     *      $from_code = true 时， 表示用户首次下单，header 跳转后 $order_data 为空，需要本函数从 cookie 获取
     *          $from_code = true 与 $token_data 必须同时传递
     *      $from_code = false 时，表示用户以前下过单，$order_data 不为空， 从前文传递过来，不需要本函数从 cookie 获取
     *          $from_code = false 与 $order_data 必须同时传递
     *
     */
    static public function create_jspay($openid, $from_code = false, $options, $order_data = null, $token_data = null) { 
            $config = \Weixin\Factory::getConfig(DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'configs');
            if($from_code) {
                $order_data = $_COOKIE[$config['common']['cookie_key']];
                $order_data = unserialize(stripslashes(\Weixin\MyFunctions::myDecrypt($order_data, $config['common']['cookie_encrypt_key'])));
            }
                $order_data['openid'] = $openid;

                $order = new \Weixin\CreateOrder($order_data, DAQIN_WEIXIN_PAY_PLUGIN_DIR);
                $result = $order->jspay();
                $result = json_decode($result, true);
            if(0 == $result['errno']) {
                $res = \Weixin\UnifiedOrder::wxpay($result['data']['xml'], $result['data']['mchkey']);


                if('SUCCESS' == $res['result_code'] && 'SUCCESS' == $res['return_code']) {
                    
                    $weixin = new \Weixin\weixinData();
                    $jsApiParameters = $weixin->makeJsSign($res['prepay_id'], $options['appid'], $options['mchkey']);
                    $jsApiParameters = json_encode($jsApiParameters);

                    global $wpdb;
                    $table_name = $wpdb->prefix . $config['common']['order_table_name'];
                    $wpdb->insert($table_name, $result['db_data']);

                    setcookie($_COOKIE[$config['common']['cookie_key']], '', (time() - 60), '/');

                    session_start();
                    $mobile_session_key = $result['db_data']['customer_mobile'] . '_code';
                    if(isset($_SESSION[$mobile_session_key])) {
                        $mobile_session_expire_key = $result['db_data']['customer_mobile'] . '_expire';
                        unset($_SESSION[$mobile_session_key]);
                        unset($_SESSION[$mobile_session_expire_key]);
                    }

                    if($token_data) {
                        $token_table = $wpdb->prefix . $config['common']['token_table_name'];
                        $time = time();
                        $end_time = $time + $token_data['expires_in'];

                        if($from_code) {
                            $wpdb->query( $wpdb->prepare( 
                                "
                                    INSERT INTO $token_table
                                    ( openid, access_token, refresh_token, scope, end_time )
                                    VALUES ( %s, %s, %s, %s, %d )
                                ", 
                                    array(
                                    $token_data['openid'], 
                                    $token_data['access_token'], 
                                    $token_data['refresh_token'],
                                    $token_data['scope'],
                                    $end_time
                                ) 
                            ));

                            /*
                            $wpdb->insert(
                                $token_table, 
                                array( 
                                    'openid' => $token_data['openid'],
                                    'access_token' => $token_data['access_token'],
                                    'refresh_token' => $token_data['refresh_token'],
                                    'scope' => $token_data['scope'],
                                    'end_time' => $end_time,
                                ), 
                                array( 
                                    '%s',
                                    '%s', 
                                    '%s',
                                    '%s',
                                    '%d',
                                ) 
                            );
                             */

                            $cookie_token = \Weixin\MyFunctions::myCrypt($token_data['openid'], $config['common']['cookie_encrypt_key']);
                            $cookie_expire =  $time + $config['common']['expire_month'];
                            $cookie_flag = setcookie($config['common']['token_cookie_key'], $cookie_token, $cookie_expire, '/');
                        }else {
                            $wpdb->update( 
                                    $token_table, 
                                    array( 
                                        'openid' => $token_data['openid'],
                                        'access_token' => $token_data['access_token'],
                                        'refresh_token' => $token_data['refresh_token'],
                                        'scope' => $token_data['scope'],
                                        'end_time' => $end_time,
                                    ), 
                                    array( 'openid' => $token_data['openid'] ), 
                                    array( 
                                        '%s',
                                        '%s',
                                        '%s',
                                        '%s',
                                        '%d',
                                    ), 
                                    array( '%s' ) 
                            );
                        }
                    }

                    include DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'tpl/jsapi.htm';
                }else {
                    echo '统一下单失败';
                }
            }else {
                echo '<h3>'.$result['errmsg'].'</h3>';
            }
    }

}
