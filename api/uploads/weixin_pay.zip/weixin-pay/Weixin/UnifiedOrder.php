<?php
/*
 +----------------------------------------------------------------------+
 | unified order                                                        |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:56:58                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class UnifiedOrder{
    
    /**
     *
     *      直接 xml 提交统一下单
     *
     */
    public static function wxpay($xml, $mch_key) {

        $url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';

        $result = self::postXmlCurl($xml, $url);

        $result = \Weixin\WeixinResult::Init($result, $mch_key);
        return $result;
    }

    /**
     *
     *      查询订单
     *
     */
    public static function query_order($xml, $mch_key) {

        $url = 'https://api.mch.weixin.qq.com/pay/orderquery';

        $result = self::postXmlCurl($xml, $url);

        $result = \Weixin\WeixinResult::Init($result, $mch_key);
        return $result;
    }

	private static function postXmlCurl($xml, $url, $apiclient_cert_path = '', $apiclient_key_path = '', $second = 30)
	{		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,TRUE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	
		if($apiclient_cert_path){
			curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
			curl_setopt($ch,CURLOPT_SSLCERT, $apiclient_cert_path);
			curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
			curl_setopt($ch,CURLOPT_SSLKEY, $apiclient_key_path);
		}
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		$data = curl_exec($ch);
		if($data){
			curl_close($ch);
			return $data;
		} else { 
			$error = curl_errno($ch);
            $error .= '<br />';
			$error .= curl_error($ch);
			curl_close($ch);
			throw new Exception("curl出错，错误码:$error");
		}
	}

}
