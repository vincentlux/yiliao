<?PHP
/*
 +----------------------------------------------------------------------+
 | Factory                                                              |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:42:22                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class Factory {
    static $proxy = null;

    static function getConfig($config_dir) {
        $key = 'config_';
        $config = \Weixin\Register::get($key);
        if(! $config) {
            $class = '\\Weixin\Config';
            $config = new $class($config_dir);
            Register::set($key, $config);
        }
        return $config;
    }

}
