<?PHP 
    /**
     *
     *      小程序日志
     *          author by qinziheng
     *          2017-12-29 16:29:28
     *          QQ/微信     68183131
     *          website:    https://www.qinziheng.com
     *
     */
namespace Weixin;

    class Logger {
        private static $max_file_size = 5242880;   // 日志文件最大值， 大于这个后会重命名； 1k = 1 048 576
        /**
         *
         *      写入日志
         *          param   $file_path  string  文件名称
         *          param   $content    string  日志内容
         *
         *          return  array
         *              array['errno'] = 0 表示代码码，0 表示成功
         *              array['errmsg'] = string    表示返回提示信息
         *
         */
        public static function write($file_path = 'rs.txt', $content = '') {
            $res = array();
            $res['errno'] = 0;
            $res['errmsg'] = 'ok';

            if(empty($content)) {
                $res['errno'] = 400001;
                $res['errmsg'] = 'content empty';
                return json_encode($res);
            }

            $fh = fopen($file_path, 'ab');
            if($fh) {
                if(flock($fh, LOCK_EX)) {
                    $date = date('Y-m-d H:i:s');
                    $content = $date . "\n" . $content;
                    $content .= "\n\n";

                    if(! fwrite($fh, $content)) {
                        $res['errno'] = 400003;
                        $res['errmsg'] = 'write content fail';
                    }

                    fflush($fh);
                    flock($fh, LOCK_UN);
                }else {
                        $res['errno'] = 400004;
                        $res['errmsg'] = 'lock file fail';
                }

                fclose($fh);

                clearstatcache();

                if(filesize($file_path) > self::$max_file_size) {
                    rename($file_path, date('Y-m-d') . '_' . $file_path);
                }
            }else {
                $res['errno'] = 400002;
                $res['errmsg'] = 'can not open file';
            }
            return json_encode($res);
        }

    }
