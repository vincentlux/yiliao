<?PHP
/*
 +----------------------------------------------------------------------+
 | query order                                                          |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:51:34                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class QueryOrder  {
    protected $config;
    private $url = '';

    function __construct($action, $base_dir) {
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');
        $this->action = $action;
        $this->url = $this->config['common']['request_uri'] . '/wepay.php';
    }

    function run($parameters) {
        $rs = $this->check($parameters);
        if(0 == $rs['errno']) {
                    
            $option = array();
            $option['action'] = $this->action;
            $option['data'] = $rs['data'];

            $option['data']['pluginid'] = get_option($this->config['options']['pluginid']);

            $result = \Weixin\MyFunctions::get_web($this->url, $option);
            $result = json_decode($result, true);

            $order = \Weixin\UnifiedOrder::query_order($result['data']['xml'], $result['data']['mchkey']);
            $res = array();
            $res['errno'] = \Weixin\MyError::SUCCESS_NO;
            $res['errmsg'] = \Weixin\MyError::SUCCESS_MSG;
            if('SUCCESS' == $order['result_code'] && 'SUCCESS' == $order['return_code']) {
                if('SUCCESS' == $order['trade_state']) {
                    global $wpdb;
                    $order_table = $wpdb->prefix . $this->config['common']['order_table_name'];
                    $sql = 'select post_id, state, goods_number from ' . $order_table . ' where out_trade_no = "'. $rs['data']['gid'] .'" limit 1' ;
                    $row = $wpdb->get_row($sql, ARRAY_A);

                    if(0 == $row['state']) {
                        $option['action'] = 'OrderUpdate';
                        $update_result = \Weixin\MyFunctions::get_web($this->url, $option);
                        $update_result = json_decode($result, true);
                        if(0 == $update_result['errno']) {
                            $wpdb->update( 
                                    $order_table, 
                                    array( 
                                        'state' => 1
                                    ), 
                                    array( 'out_trade_no' => $rs['data']['gid'] ),
                                    array( 
                                        '%d'
                                    ), 
                                    array( '%s' )
                            );

                            $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
                            $wpdb->query( $wpdb->prepare( 
                                "
                                    update $goods_meta_table  
                                    set goods_stock = goods_stock - %d  
                                    where post_id = %d
                                ", 
                                    array(
                                    $row['goods_number'], 
                                    $row['post_id']
                                )
                            ) );

                        }
                    }
                }else {
                    $res['errno'] = \Weixin\MyError::ORDER_WEIXIN_ERRNO;
                    $res['errmsg'] = $order['trade_state'];
                }
            }else {
                $res['errno'] = \Weixin\MyError::ORDER_NOPAY_ERRNO;
                $res['errmsg'] = \Weixin\MyError::ORDER_NOPAY_ERRMSG;
            }
            return json_encode($res);
        }else {
            return json_encode($rs);
        }
    }

    private function check($parameters) {
        $res = $db_data = array();
        $res['errno'] = 0;
        $res['errmsg'] = 'ok';
        

        $res['data'] = $parameters;
        return $res;
    }
}
