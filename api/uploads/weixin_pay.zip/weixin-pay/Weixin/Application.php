<?PHP
/*
 +----------------------------------------------------------------------+
 | Application                                                          |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:34:50
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class Application {
    protected $base_dir;
    protected static $instance;
    protected $config;
    protected $template_dir;
    protected $data = array();
    protected $weixin_pay_options;
    
    protected function __construct($base_dir) {
        $this->base_dir = $base_dir;
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');
        $this->template_dir = $base_dir . $this->config['common']['tpl_dir'];
    }

    static function getInstance($base_dir = '') {
        if(empty(self::$instance)) {
            self::$instance = new self($base_dir);
        }
        return self::$instance;
    }

    public function dispatch() {
        
		register_activation_hook( DAQIN_WEIXIN_PAY_PLUGIN_FILE, array($this, 'plugin_init') );
		register_activation_hook( DAQIN_WEIXIN_PAY_PLUGIN_FILE, array($this, 'goto_weixin_config') );
        add_action('admin_menu', array($this, 'weixin_pay_add_menu'));
        add_action('admin_menu', array($this, 'weixin_order_menu'));
        add_action('admin_menu', array($this, 'weixin_order_detail'));
        add_action('admin_menu', array($this, 'manage_stock'));
        add_action('admin_menu', array($this, 'weixin_order_sms'));
        add_action( 'add_meta_boxes', array($this, 'post_goods_meta') );
        add_action( 'delete_post', array($this, 'delete_goods_meta') );
        add_action( 'trash_post', array($this, 'delete_goods_meta') );
        add_action( 'untrash_post', array($this, 'undelete_goods_meta') );
        add_action( 'publish_post', array($this, 'save_post_meta') );
        add_action( 'edit_post', array($this, 'save_post_meta') );
        add_filter('the_content', array($this, 'add_goods_form'));
    }

    public function save_post_meta( $post_id ) {
        $goods_price = \Weixin\MyFunctions::get($this->config['goods']['goods_price'], 'post');
        $goods_name = \Weixin\MyFunctions::get($this->config['goods']['goods_name'], 'post');
        if(empty($goods_name)) {
            $goods_name = get_the_title( $post_id );
        }
        $goods_stock = \Weixin\MyFunctions::get($this->config['goods']['goods_stock'], 'post');
        if(empty($goods_stock)) {
            $goods_stock = 0;
        }

        global $wpdb;
        $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
        $db_action = \Weixin\MyFunctions::get('db_action', 'post');

        if ( $goods_price > 0 ) {
            $is_delete = 0;
            if('add' == $db_action) {
                $wpdb->insert( 
                    $goods_meta_table, 
                    array( 
                        'post_id' => $post_id,
                        'goods_name' => $goods_name,
                        'goods_price' => $goods_price,
                        'goods_stock' => $goods_stock,
                        'is_delete' => $is_delete,
                    ), 
                    array( 
                        '%d',
                        '%s', 
                        '%d',
                        '%d',
                        '%d',
                    ) 
                );
            }else {
                $wpdb->update( 
                        $goods_meta_table, 
                        array( 
                            'goods_name' => $goods_name,
                            'goods_price' => $goods_price,
                            'goods_stock' => $goods_stock,
                            'is_delete' => $is_delete,
                        ), 
                        array( 'post_id' => $post_id ), 
                        array( 
                            '%s',
                            '%d',
                            '%d',
                            '%d',
                        ), 
                        array( '%d' ) 
                );
            }
        }

        if('update' == $db_action && empty($goods_price)) {
            $goods_name = \Weixin\MyFunctions::get($this->config['goods']['goods_name'], 'post');
            $goods_stock = \Weixin\MyFunctions::get($this->config['goods']['goods_stock'], 'post');
            $is_delete = 1;
            $wpdb->update( 
                        $goods_meta_table, 
                        array( 
                            'goods_name' => $goods_name,
                            'goods_price' => $goods_price,
                            'goods_stock' => $goods_stock,
                            'is_delete' => $is_delete,
                        ), 
                        array( 'post_id' => $post_id ), 
                        array( 
                            '%s',
                            '%d',
                            '%d',
                            '%d',
                        ), 
                        array( '%d' ) 
                );
        }
    }

    public function post_goods_meta() {
        add_meta_box( 'goods-meta', '产品信息-大秦微信支付', array($this, 'add_goods_meta'), 'post', 'advanced', 'high' );
    }

    public function add_goods_meta( $post ) {
        $pluginid = get_option($this->config['options']['pluginid']);
        $options = get_option($this->config['options']['common']);

        if($pluginid && $options) {
            $goods_config = $this->config['goods'];

            global $wpdb;
            $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
            $sql = 'select goods_name, goods_price, goods_stock from ' . $goods_meta_table . ' where post_id = '. $post->ID .' limit 1';
            $goods_meta = $wpdb->get_results($sql, ARRAY_A);
            $goods_meta = $goods_meta[0];
            if(count($goods_meta) > 0) {
                $db_action = 'update';
            }else {
                $db_action = 'add';
            }
            $this->assign('goods_config', $goods_config);
            $this->assign('goods_meta', $goods_meta);
            $this->assign('db_action', $db_action);
        }

        //echo admin_url();   // https://www.qinziheng.com/wp-admin/
        $this->assign('pluginid', $pluginid);
        $this->assign('options', $options);
        $this->assign('page_slug', $this->config['common']['page_slug']);

        $this->display('post_meta');
    }

    /**
     *
     *      分配变量
     *
     */
    public function assign($key, $value) {
        $this->data[$key] = $value;
    }

    public function display($file = '') {
        if(empty($file)) {
            $file = $this->template_dir . '/index.htm';
        }
        $path = $this->template_dir . '/' . $file . '.htm';
        extract($this->data);
        include($path);
    }


    public function weixin_pay_add_menu(){   
      add_menu_page( '微信支付配置', '微信支付', 'edit_themes', 'weixin_pay',array($this, 'weixin_pay_option'),'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAOzSURBVHjahJLdT1t1HMaf38vpOaVA23PaAm0ZFIqY8TLHUGJmgpo5FrdEE2+cf8OMM5pMvTJeqFfOqJfGLMvijYkv8QUTLibThbgJxCUGGDpsYbwVCi1rS8/5vXhRJVsW5nPzvfo+eb7f50OSQ23w+UzEojGEmh3Um/U+k/lGgv7Q8Whj9BGT+pq01kQSuZYr5qY3ihujW8X82GYx79WZfhSKBbjCBce/ElLA4ubRnvjB923LfsLgBqSS0FqDEAJopCNNkaMiJs6sbK1cnpibeMMV1Wv/7bPGZAhSK3QkO08/1fP0FyEr2Kmg9kw09N6UWgIasOvtVKopdbpQLq6u59dvaGhNtdaIhWNDx44c/9TkZp0rPWitsZ80NDzpodFqrD+UOvSOP+CPaKXBw2HHf+yxZ877fVZd1a3iQaKEglKKilvJZ7ayn03euv6x40QS5a0dwZvDTSfamlOPu17NxGAGhBL3pKKEglGGslfO395YvpDZyJzfETvLqWjHub4DfW+OFr9/jXenDz5HAEATSCUq86vzP3Q1p08xyk2tNTjjKLmlreXNlUtTC5MfSCX/joWbHj0SH7jUFm4bZpShN913ijcFY31SSmhoWD7LN5+d++bP23MXTwyevOhJQTOrcxeKXvGT3HbuJmfcSDen3+1N9L5qMtNyhQtKKJrtlm7OCAvd9QZ2+KHBM6O/fjc0Of/b8K7eRTa3+LvdYMNpdEY6Ih3vtQRbDgsp4Er3rgaInyuo3T2WhEDCjg8GjMBwZj077vdbSDiJqB2w3+o/0P8yJ5y5wr2/SaJcWrhTWGCM7VVrcIN2Jbtfym5mYRrWswNtA5cH2gfOEk2YJ737TBhlKOxsZ/j0zPS36Xj6JAGpMeJ56Ovse9F27GS70z7CmcE84e2LBOccs5mZH5kO469UovP5YCAYkar2dIMZZrQh2qW0okrJfU0MbmCjuLEyfv2nV6jrutsTf1x9XUG5jNZOVFrBFe4DCaeEglCCqZtT50ql0hKz01FIyPmSV87F7cSTlFAf/keccjCDY+z62Ns/Xxv/SEoJluhvhScFMmuZyVAg2JN0kv0UNZJBaouEEFBCwRkHYwzb5e2lqcWps1dv/PKhe6cKQgl42AoDWkNYwnQanIelUsgUMl8xzeobrYZ+H/fVEQBV6VZKbnl+vbD2dW4793lJlZY546CU1lIuZG5BSAEnHGmlPla8MnvlhYIoflmtVACFeFdrd4RzjtnFmbwmailkhUApBQO759x/BgC2XbDr13GjkgAAAABJRU5ErkJggg==',6);   
    }   
       
    public function weixin_pay_option(){
            $common_options = get_option($this->config['options']['common']);
            $common_options = unserialize($common_options);

            $options = get_option($this->config['options']['register']);
            $options = unserialize($options);
            if(isset($options['appsecret'])) {
                $options['appsecret'] = \Weixin\MyFunctions::myDecrypt($options['appsecret'], $this->config['common']['cookie_encrypt_key']);
            }

            if(isset($options['mchid'])) {
                $options['mchid'] = \Weixin\MyFunctions::myDecrypt($options['mchid'], $this->config['common']['cookie_encrypt_key']);
            }
            if(isset($options['mchkey'])) {
                $options['mchkey'] = \Weixin\MyFunctions::myDecrypt($options['mchkey'], $this->config['common']['cookie_encrypt_key']);
            }
            
            $has_address = array('', '');
            if(isset($common_options['has_address'])) {
                $has_address[$common_options['has_address']] = 'checked="checked"';
            }else {
                $has_address[1] = 'checked="checked"';
            }

            $has_remark = array('', '');
            if(isset($common_options['has_remark'])) {
                $has_remark[$common_options['has_remark']] = 'checked="checked"';
            }else {
                $has_remark[0] = 'checked="checked"';
            }

            $has_vcode = array('', '');
            if(isset($common_options['has_vcode'])) {
                $has_vcode[$common_options['has_vcode']] = 'checked="checked"';
            }else {
                $has_vcode[0] = 'checked="checked"';
            }

            $has_name = array('', '');
            if(isset($common_options['has_name'])) {
                $has_name[$common_options['has_name']] = 'checked="checked"';
            }else {
                $has_name[1] = 'checked="checked"';
            }

            $has_mobile = array('', '');
            if(isset($common_options['has_mobile'])) {
                $has_mobile[$common_options['has_mobile']] = 'checked="checked"';
            }else {
                $has_mobile[1] = 'checked="checked"';
            }

            $has_h5pay = array('', '');
            if(isset($common_options['has_h5pay'])) {
                $has_h5pay[$common_options['has_h5pay']] = 'checked="checked"';
            }else {
                $has_h5pay[0] = 'checked="checked"';
            }

            $check_mobile = array('', '');
            if(isset($common_options['check_mobile'])) {
                $check_mobile[$common_options['check_mobile']] = 'checked="checked"';
            }else {
                $check_mobile[0] = 'checked="checked"';
            }

            $has_order_sms = array('', '');
            if(isset($common_options['has_order_sms'])) {
                $has_order_sms[$common_options['has_order_sms']] = 'checked="checked"';
            }else {
                $has_order_sms[0] = 'checked="checked"';
            }

            $clear_data = array('', '');
            if(isset($common_options['clear_data'])) {
                $clear_data[$common_options['clear_data']] = 'checked="checked"';
            }else {
                $clear_data[0] = 'checked="checked"';
            }

            $this->assign('options', $options);
            $this->assign('common_config', $this->config['common']);
            $this->assign('common_options', $common_options);
            $this->assign('has_address', $has_address);
            $this->assign('has_remark', $has_remark);
            $this->assign('has_vcode', $has_vcode);
            $this->assign('has_name', $has_name);
            $this->assign('has_mobile', $has_mobile);
            $this->assign('has_h5pay', $has_h5pay);
            $this->assign('check_mobile', $check_mobile);
            $this->assign('has_order_sms', $has_order_sms);
            $this->assign('clear_data', $clear_data);
            $this->display('option');
    }   

    public function weixin_order_menu() {  
      add_submenu_page( 'weixin_pay', '微信支付订单管理', '订单列表', 'edit_themes', 'weixin_order', array($this, 'weixin_order_list') );  
    }  
     
    public function weixin_order_list() {  
        global $wpdb;
        $order_table = $wpdb->prefix . $this->config['common']['order_table_name'];
        $sql = 'select count(*) from ' . $order_table . ' limit 1';
        $total = $wpdb->get_var($sql);

        $page = new \Weixin\Page($total, $this->config['common']['page_per_number'], '', 'paged');
        $sql = 'select id, post_id, goods_name, total_fee, customer_name, customer_mobile, customer_address, out_trade_no, state, create_time from ' . $order_table . ' order by id desc limit ' . $page->limit[0] . ', ' . $page->limit[1];
        $rs = $wpdb->get_results($sql, ARRAY_A);

        $submit_url = WP_PLUGIN_URL . '/' . $this->config['common']['plugin_name'] . '/submit.php';

        $this->assign('rs', $rs);
        $this->assign('page', $page);
        $this->assign('submit_url', $submit_url);
        $this->display('query_order_form');
        $this->display('order_list');
     
    }
    
    public function weixin_order_detail() {  
      add_submenu_page( 'weixin_pay', '微信支付订单管理', '查询订单', 'edit_themes', 'weixin_order_detail', array($this, 'weixin_order_detail_show') );  
    }  

    public function weixin_order_detail_show() {
        $out_trade_no = \Weixin\MyFunctions::get('gid');
        global $wpdb;
        $order_table = $wpdb->prefix . $this->config['common']['order_table_name'];
        $sql = 'select goods_name, goods_price, goods_number, total_fee, customer_name, customer_mobile, customer_address, remark, out_trade_no, transaction_id, state, create_time from ' . $order_table . ' where out_trade_no = "'. $out_trade_no .'" limit 1';
        $row = $wpdb->get_row($sql, ARRAY_A);

        $submit_url = WP_PLUGIN_URL . '/' . $this->config['common']['plugin_name'] . '/submit.php';

        $this->assign('out_trade_no', $out_trade_no);
        $this->assign('row', $row);
        $this->assign('submit_url', $submit_url);
        $this->display('query_order_form');
        $this->display('order_detail');
    }

    public function manage_stock() {  
      add_submenu_page( 'weixin_pay', '微信支付库存管理', '产品库存', 'edit_themes', 'manage_stock', array($this, 'manage_stock_do') );  
    }  

    public function manage_stock_do() {
        global $wpdb;
        $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
        $sql = 'select count(*) from ' . $goods_meta_table . ' where is_delete = 0 limit 1';
        $total = $wpdb->get_var($sql);

        $page = new \Weixin\Page($total, $this->config['common']['page_per_number'], '', 'paged');
        $sql = 'select id, post_id, goods_name, goods_price, goods_stock from ' . $goods_meta_table . ' where is_delete = 0 order by id desc limit ' . $page->limit[0] . ', ' . $page->limit[1];
        $rs = $wpdb->get_results($sql, ARRAY_A);

        $this->assign('rs', $rs);
        $this->assign('page', $page);
        $this->display('stock_manage');
    }

    public function weixin_order_sms() {  
      add_submenu_page( 'weixin_pay', '微信支付短信管理', '短信管理', 'edit_themes', 'weixin_sms', array($this, 'weixin_order_sms_list') );  
    }  
     
    public function weixin_order_sms_list() {  

        global $wpdb;
        $sms_table = $wpdb->prefix . $this->config['common']['sms_table_name'];
        $sql = 'select count(*) from ' . $sms_table . ' limit 1';
        $total = $wpdb->get_var($sql);

        $page = new \Weixin\Page($total, $this->config['common']['page_per_number'], '', 'paged');
        $sql = 'select id, mobile, type, create_time from ' . $sms_table . ' order by id desc limit ' . $page->limit[0] . ', ' . $page->limit[1];
        $rs = $wpdb->get_results($sql, ARRAY_A);

        $sms_type = array('check' => '验证码', 'order' => '订单通知');

        $this->assign('rs', $rs);
        $this->assign('page', $page);
        $this->assign('sms_type', $sms_type);
        $this->display('sms_list');
    }


    public function add_goods_form($content) {
        if(is_single() || is_home() || is_category() || is_tag() || is_search() || is_feed() ) {

            global $wpdb;
            $post_id = get_the_ID();
            $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
            $sql = 'select goods_name, goods_price, goods_stock from '.$goods_meta_table.' where post_id = '.$post_id.' order by id desc limit 1';
            $goods_meta = $wpdb->get_row($sql, ARRAY_A);

            $options = get_option($this->config['options']['common']);
            $options = unserialize($options);

            $user_info = $_COOKIE[$this->config['common']['user_info_cookie_key']];
            $user_info = unserialize(stripslashes(\Weixin\MyFunctions::myDecrypt($user_info, $this->config['common']['cookie_encrypt_key'])));

            $is_mobile = wp_is_mobile();
            if($is_mobile && (! \Weixin\MyFunctions::is_weixin()) && (! $options['has_h5pay'])) {
                return $content;
            }


            if($goods_meta['goods_price'] > 0 && $goods_meta['goods_stock'] > $options['warn_stock']) {
                if($is_mobile) {
                    $h5_class = ' h5-font';
                    $button_class = ' button-mobile';
                }else {
                    $h5_class = '';
                    $button_class = '';
                }
                $submit_url = WP_PLUGIN_URL . '/' . $this->config['common']['plugin_name'] . '/submit.php';

                $ip = \Weixin\MyFunctions::IP();

                $tmp = array('{{plugin_url}}', '{{submit_url}}', '{{goods_name}}', '{{goods_price}}', '{{gid}}', '{{ip}}', '{{h5_class}}');

                $goods_price = $goods_meta['goods_price'] * 0.01;
                $dest = array(DAQIN_WEIXIN_PAY_PLUGIN_URL, $submit_url,  $goods_meta['goods_name'], $goods_price, $post_id, $ip, $h5_class);
                if($options['has_name']) {
                    $name_html = '
                        <tr valign="top">
                            <th class="zi-td-label'.$h5_class.'"><label for="name">姓　　名<span class="red">*</span></label></th>
                            <td><input type="text" id="name" maxlength="10" class="zi-input" name="name" value="'. (isset($user_info['name']) ? $user_info['name'] : '') .'" placeholder="如:秦子恒" /></td>
                        </tr>
                    ';

                    array_push($tmp, '<span id="name-pos"></span>');
                    array_push($dest, $name_html);
                }

                if($options['has_mobile']) {
                    $mobile_html = '
                        <tr valign="top">
                            <th class="zi-td-label'.$h5_class.'"><label for="mobile">联系手机<span class="red">*</span></label></th>
                            <td><input type="number" id="mobile" maxlength="11"  min="13000000000" max="18999999999" class="zi-input" name="mobile" value="'. (isset($user_info['mobile']) ? $user_info['mobile'] : '') .'" placeholder="如:13068183131" /></td>
                        </tr>
                    ';

                    array_push($tmp, '<span id="mobile-pos"></span>');
                    array_push($dest, $mobile_html);

                    if($options['check_mobile']) {
                        $code_html = '
                            <tr valign="top">
                                <th class="zi-td-label'.$h5_class.'"><button id="check-mobile" class="'.$button_class.'">获取验证码</button></th>
                                <td><input type="text" id="mobile-code" class="zi-input" name="mobile_code" value="" placeholder="手机验证码" /></td>
                            </tr>
                            ';

                        array_push($tmp, '<span id="check-pos"></span>');
                        array_push($dest, $code_html);
                    }
                }

                if($options['has_address']) {
                    $address_html = '
                        <tr valign="top">
                            <th class="zi-td-label'.$h5_class.'"><label for="address">收货地址<span class="red">*</span></label></th>
                            <td><input type="text" id="address" class="zi-input" name="address" value="'. (isset($user_info['address']) ? $user_info['address'] : '') .'" placeholder="如:桂林市中山路168号" /></td>
                        </tr>
                        ';

                    array_push($tmp, '<span id="address-pos"></span>');
                    array_push($dest, $address_html);
                }

                if(isset($user_info['mobile'])) {
                    $order_table = $wpdb->prefix . $this->config['common']['order_table_name'];
                    $sql = 'select create_time from ' . $order_table . ' where customer_mobile = "'.$user_info['mobile'].'" and customer_name = "'.$user_info['name'].'" and post_id = "'.$post_id.'" and create_ip = "'.$ip.'" and state = 1 order by create_time desc limit 1';
                    $create_time = $wpdb->get_var($sql);
                    if($create_time) {
                        $order_state_html = ' <span class="green">购买时间， '.date('Y-m-d H:i:s', $create_time).'</span>';
                        array_push($tmp, '<span id="order-state-pos"></span>');
                        array_push($dest, $order_state_html);
                    }else {
                        $order_state_html = '';
                    }
                }

                if($options['has_remark']) {
                    $remark_html = '
                        <tr valign="top">
                            <th class="zi-td-label'.$h5_class.'"><label for="address">留言备注</label></th>
                            <td><textarea name="remark" id="remark" style="width:200px;height:75px"></textarea></td>
                        </tr>
                        ';

                    array_push($tmp, '<span id="remark-pos"></span>');
                    array_push($dest, $remark_html);
                }

                if($options['has_vcode']) {
                    $has_vcode = true;
                }else {
                    $start_time = mktime(0,0,0,date('m'),date('d'),date('Y'));
                    $sql = 'select count(*) from ' . $wpdb->prefix . $this->config['common']['order_table_name'] . ' where  create_time > ' . $start_time;
                    $today_order_count = $wpdb->get_var($sql);
                    if($today_order_count > $this->config['common']['order_trigger_vcode']) {
                        $has_vcode = true;
                    }else {
                        $has_vcode = false;
                    }
                }
                if($has_vcode) {
                    $vcode_url = DAQIN_WEIXIN_PAY_PLUGIN_URL . 'vcode.php';
                    $vcode_html = '
                        <tr valign="top">
                            <th class="zi-td-label"><img src="'.$vcode_url.'"  onclick="this.src=\''.$vcode_url.'?\'+Math.random();"> </th>
                            <td><input type="text" id="vcode" maxlength="4"  class="zi-input" name="vcode" value="" placeholder="验证码" onkeyup="this.value = this.value.toUpperCase();" /></td>
                        </tr>
                        ';

                    array_push($tmp, '<span id="vcode-pos"></span>');
                    array_push($dest, $vcode_html);
                }

                if($options['has_name'] || $options['has_mobile'] || $options['has_address']) {
                    if($user_info) {
                        $cookie_button_html = '<button class="text-left" id="clear-cookie">清除缓存</button>';
                    }else {
                        $cookie_button_html = '<button class="text-left disabled-button" id="clear-cookie" disabled="disabled">清除缓存</button>';
                    }
                }
                array_push($tmp, '<span id="clear-pos"></span>');
                array_push($dest, $cookie_button_html);



                $html = file_get_contents(WP_PLUGIN_DIR . '/' . $this->config['common']['plugin_name'] . '/tpl/goods_form.htm');
                $html = str_replace($tmp, $dest, $html);
                $html .= '<script src="'.WP_PLUGIN_URL. '/' . $this->config['common']['plugin_name'] . '/js/form.js" async defer></script>';

                $content .= '<br />';

                $content .= $html;


                $content .= '<br />';
            }
        }
        return $content;
    }

    public function plugin_init() {
        if(! extension_loaded('curl') || ! extension_loaded('mysqli')) {
            exit('please install php curl extension and mysqli extension');
        }

        global $wpdb;

        $sql_tpl = "
            CREATE TABLE `%s` (
                  `id` int  NOT NULL AUTO_INCREMENT,
                  `post_id` int unsigned NOT NULL DEFAULT '0' COMMENT '产品 id， wordpress对应文章id',
                  `goods_name` varchar(100) NOT NULL DEFAULT '' COMMENT '产品名称',
                  `goods_price` int unsigned NOT NULL DEFAULT '0' COMMENT '产品价格，单位 分',
                  `goods_number` int unsigned NOT NULL DEFAULT '0' COMMENT '产品数量',
                  `total_fee` int unsigned NOT NULL DEFAULT '0' COMMENT '订单总金额， 单位 分',
                  `customer_name` varchar(50) NOT NULL DEFAULT '' COMMENT '客户姓名',
                  `customer_mobile` char(11) NOT NULL DEFAULT '0' COMMENT '客户手机',
                  `customer_address` varchar(100) NOT NULL DEFAULT '' COMMENT '收货地址',
                  `remark` varchar(300) NOT NULL DEFAULT '' COMMENT '备注',
                  `out_trade_no` char(32) NOT NULL DEFAULT '' COMMENT '商户订单号',
                  `transaction_id` char(32) NOT NULL DEFAULT '' COMMENT '微信订单号；异步返回结果中才有',
                  `state` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '订单状态',
                  `order_xml` text COMMENT '微信订单号；异步返回结果中才有',
                  `notify_xml` text COMMENT '微信返回的订单xml信息',
                  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '订单生成时间',
                  `create_ip` char(15) NOT NULL DEFAULT '' COMMENT '生成订单的用户IP',
                  `is_delete` tinyint NOT NULL DEFAULT '0' COMMENT '',
                  PRIMARY KEY (`id`),
                  index (`goods_name`),
                  index mobile_post_id (`customer_mobile`, `post_id`),
                  unique (`out_trade_no`),
                  index (`transaction_id`),
                  index (`create_time`)
                ) ENGINE=innodb DEFAULT CHARSET=utf8;
            ";
            $table_name = $wpdb->prefix . $this->config['common']['order_table_name'];
            $sql = sprintf($sql_tpl, $table_name);

            require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
            if($wpdb->get_var("show tables like '$table_name'") != $table_name){
                dbDelta($sql);
            }

            if($wpdb->last_error) {
                exit('order table can not create');
            }

            $sql_tpl = "
            CREATE TABLE `%s` (
                  `id` int  NOT NULL AUTO_INCREMENT,
                  `post_id` int unsigned NOT NULL DEFAULT '0' COMMENT '产品 id， 对应wordpress文章id',
                  `goods_name` varchar(100) NOT NULL DEFAULT '' COMMENT '产品名称',
                  `goods_price` int unsigned NOT NULL DEFAULT '0' COMMENT '产品价格，单位 分',
                  `goods_stock` int unsigned NOT NULL DEFAULT '0' COMMENT '产品数量',
                  `is_delete` tinyint NOT NULL DEFAULT '0' COMMENT '',
                  PRIMARY KEY (`id`),
                  unique (`post_id`),
                  index (`goods_name`)
                ) ENGINE=innodb DEFAULT CHARSET=utf8;
            ";
            $table_name = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
            $sql = sprintf($sql_tpl, $table_name);

            if($wpdb->get_var("show tables like '$table_name'") != $table_name){
                dbDelta($sql);
            }

            if($wpdb->last_error) {
                exit('goods_meta table can not create');
            }

            $sql_tpl = "
            CREATE TABLE `%s` (
                      `id` int  NOT NULL AUTO_INCREMENT,
                      `openid` varchar(64) NOT NULL DEFAULT 'check' COMMENT 'openid',
                      `access_token` varchar(128) NOT NULL DEFAULT '0' COMMENT 'access_token',
                      `refresh_token` varchar(256) NOT NULL DEFAULT '0' COMMENT 'refresh_token',
                      `scope` varchar(32) NOT NULL DEFAULT 'check' COMMENT '授权类型',
                      `end_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '到期时间time + expires_in',
                      PRIMARY KEY (`id`),
                      index (`openid`),
                      index (`end_time`)
                    ) ENGINE=innodb DEFAULT CHARSET=utf8;
            ";
            $table_name = $wpdb->prefix . $this->config['common']['token_table_name'];
            $sql = sprintf($sql_tpl, $table_name);

            if($wpdb->get_var("show tables like '$table_name'") != $table_name){
                dbDelta($sql);
            }

            if($wpdb->last_error) {
                exit('weixin token table can not create');
            }

            $sql_tpl = "
                    CREATE TABLE `%s` (
                      `id` int  NOT NULL AUTO_INCREMENT,
                      `mobile` char(11) NOT NULL DEFAULT '0' COMMENT '手机号',
                      `type` char(10) NOT NULL DEFAULT 'check' COMMENT '短信类型：check 验证短信， order 订单通知短信',
                      `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '生成时间',
                      `create_ip` char(15) NOT NULL DEFAULT '' COMMENT '生成用户IP',
                      `is_delete` tinyint NOT NULL DEFAULT '0' COMMENT '',
                      PRIMARY KEY (`id`),
                      index (`mobile`),
                      index (`create_time`)
                    ) ENGINE=innodb DEFAULT CHARSET=utf8;
            ";
            $table_name = $wpdb->prefix . $this->config['common']['sms_table_name'];
            $sql = sprintf($sql_tpl, $table_name);

            if($wpdb->get_var("show tables like '$table_name'") != $table_name){
                dbDelta($sql);
            }


        $config_path = DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'configs/common.php';
        $cookie_encrypt_key = MyFunctions::rand_string(24, true);
        if(is_writeable($config_path)) {
            $config_string = file_get_contents($config_path);
            $config_string = str_replace('{{cookie_encrypt_key}}', $cookie_encrypt_key, $config_string);
            file_put_contents($config_path, $config_string);
        }
    }

    public function goto_weixin_config() {
        if(! get_option($this->config['common']['pluginid'])) {
            wp_redirect(admin_url('admin.php?page=' . $this->config['common']['page_slug']));
        }
    }

    public function delete_goods_meta($post_id) {
        global $wpdb;
        $state = 1;
        $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
        $wpdb->update( 
                $goods_meta_table, 
                array( 
                    'is_delete' => $state,
                ), 
                array( 'post_id' => $post_id ), 
                array( 
                    '%d',
                ), 
                array( '%d' ) 
        );
    }

    public function undelete_goods_meta($post_id) {
        global $wpdb;
        $state = 0;
        $goods_meta_table = $wpdb->prefix . $this->config['common']['goods_meta_table_name'];
        $wpdb->update( 
                $goods_meta_table, 
                array( 
                    'is_delete' => $state,
                ), 
                array( 'post_id' => $post_id ), 
                array( 
                    '%d',
                ), 
                array( '%d' ) 
        );
    }

}
