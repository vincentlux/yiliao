<?PHP
/*
 +----------------------------------------------------------------------+
 | create order                                                         |
 | Author:         QinZiHeng <68183131@qq.com>                          |
 | 秦子恒微信课堂: http://211.qinziheng.com                             |
 | QQ/微信:        68183131                                             |
 | date & time     2018-04-24 17:41:31                                  |
 +----------------------------------------------------------------------+
 | DaQin Wordpress Weixin Pay Plugin                                    |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | 68183131@qq.com so we can mail you a copy immediately.               |
 +----------------------------------------------------------------------+
 */
namespace Weixin;

class CreateOrder  {
    protected $config;
    private $url = '';
    private $data = array();

    function __construct($data, $base_dir) {
        $this->data = $data;
        $this->config = \Weixin\Factory::getConfig($base_dir . 'configs');;
        $this->url = $this->config['common']['request_uri'] . '/wepay.php';
        
    }

    public function jspay() {
        $option = array();
        $option['action'] = 'Jspay';
        $option['data']['pluginid'] = get_option($this->config['options']['pluginid']);
        $option['data']['goods_number'] = $this->data['goods_number'];
        $option['data']['goods_price'] = $this->data['goods_price'];
        $option['data']['goods_name'] = $this->data['goods_name'];
        $option['data']['mobile'] = $this->data['mobile'];
        $option['data']['ip'] = $this->data['ip'];
        $option['data']['name'] = $this->data['name'];
        $option['data']['address'] = $this->data['address'];
        $option['data']['remark'] = $this->data['remark'];
        $option['data']['gid'] = $this->data['gid'];
        $option['data']['openid'] = $this->data['openid'];

        $result = \Weixin\MyFunctions::get_web($this->url, $option);
        return $result;
    }

    public function h5pay() {
        $option = array();
        $option['action'] = 'H5pay';
        $option['data']['pluginid'] = get_option($this->config['options']['pluginid']);
        $option['data']['goods_number'] = $this->data['goods_number'];
        $option['data']['goods_price'] = $this->data['goods_price'];
        $option['data']['goods_name'] = $this->data['goods_name'];
        $option['data']['mobile'] = $this->data['mobile'];
        $option['data']['ip'] = $this->data['ip'];
        $option['data']['name'] = $this->data['name'];
        $option['data']['address'] = $this->data['address'];
        $option['data']['remark'] = $this->data['remark'];
        $option['data']['gid'] = $this->data['gid'];

        $result = \Weixin\MyFunctions::get_web($this->url, $option);
        $result = json_decode($result, true);
        $result['option'] = $option;
        $result = json_encode($result);

        return $result;
    }

    public function native() {
        $option = array();
        $option['action'] = 'Native';
        $option['data']['pluginid'] = get_option($this->config['options']['pluginid']);
        $option['data']['goods_number'] = $this->data['goods_number'];
        $option['data']['goods_price'] = $this->data['goods_price'];
        $option['data']['goods_name'] = $this->data['goods_name'];
        $option['data']['mobile'] = $this->data['mobile'];
        $option['data']['ip'] = $this->data['ip'];
        $option['data']['name'] = $this->data['name'];
        $option['data']['address'] = $this->data['address'];
        $option['data']['remark'] = $this->data['remark'];
        $option['data']['gid'] = $this->data['gid'];

        $result = \Weixin\MyFunctions::get_web($this->url, $option);

        return $result;
    }

    private function check($parameters) {
        $res = $db_data = array();
        $res['errno'] = 0;
        $res['errmsg'] = 'ok';

        $res['data'] = $parameters;
        return $res;
    }
}
