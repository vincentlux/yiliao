<?php
/*
Plugin Name: WeiXin Pay
Plugin URI: https://www.qinziheng.com/wordpress-weixin-pay
Description: 大秦微信支付特点：1） 支持微信支付，微信扫码支付，微信h5支付，并且自动识别调用； 2) 让你的wordpress网站秒变在线商城； 3） 任意一篇wordpress文章都能变成产品详情页。4） 只能安装启用一个带微信支付功能的大秦wordpress插件，否则会报错！！欢迎使用反馈，QQ/微信/WeChat：68183131
Version: 1.0.0
Author: QinZiHeng
Author URI: https://www.qinziheng.com/
License: Apache2.0
QQ/weixin/WeChat:  68183131
*/

/* 

Copyright 2018 qinziheng (QQ/微信/WeChat： 68183131 email: 68183131@qq.com)
Apache License
Version 2.0
https://www.apache.org/licenses/LICENSE-2.0.html
 
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
date_default_timezone_set('PRC');

define('DAQIN_WEIXIN_PAY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DAQIN_WEIXIN_PAY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DAQIN_WEIXIN_PAY_PLUGIN_FILE', __FILE__);

include DAQIN_WEIXIN_PAY_PLUGIN_DIR . 'Weixin/Loader.php';
spl_autoload_register('\\Weixin\\Loader::autoload');

Weixin\Application::getInstance(DAQIN_WEIXIN_PAY_PLUGIN_DIR)->dispatch();
