%cannondriver.m
% A. Ruina  Feb 10, 2000, Lecture example
%modified by RDA 09/2015
%CANNON BALL TRAJECTORY WITH QUADRATIC DRAG

global c m g           %to pass variables

gamma = 0.25; %[from Taylor at standard temp pre, Ns/m2]
D = 0.1;      %sphere diameter
%Set constants in consistant units (mks)
c=gamma*D^2;  %[drag coefficient at STP]
%c = 0;
m=5;          % mass in kg
g=9.8;         % just g
color = '-r';
theta = 32*pi/180;   %launch angle in radians
speed0= 500;         %launch speed in m/s

v0 = speed0*[cos(theta)  sin(theta)];  

z0=[ 0 0 v0]'; % order is x0, y0, vx0, vy0

tspan=[0 28];  % time interval for solution
%tspan=[0 54];  % time interval for solution

[t z] = ode45('cannonrhs',tspan, z0);


subplot(2,2,1)
plot (z(:,1), z(:,2), color)   %plot trajectory
title('Projectile Trajectory')
xlabel('x position');  ylabel('y position')
hold on 
grid on

subplot(2,2,2)
plot (t, z(:,3), color)   %plot trajectory
title('horizontal velocity vs time')
xlabel('time');  ylabel('velocity')
grid on 
hold on

subplot(2,2,3)
plot (t, z(:,4),color)   %plot trajectory
title('vertical velocity vs time')
xlabel('time');  ylabel('velocity')
grid on 
hold on

