function zdot = cannonrhs(t,z)
global c m g    % matches the global statement in the other .m file

%For clarity, unpack the variables into sensible names
x=z(1); y=z(2); vx=z(3); vy=z(4);
speed= sqrt(vx^2 + vy^2);

xdot  = vx;  
ydot  = vy;
vxdot = (1/m) * (-c) * speed * vx;
vydot = (1/m) * ((-c) * speed * vy - m*g);

%repack the variables into zdot so that ode45 gets what it wants
zdot=[xdot ydot vxdot vydot]';    % note the '. Matlab wants a column vector here.
return